using System;

namespace skmDataStructures
{
	/// <summary>
	/// Summary description for TraversalMethods.
	/// </summary>
	public enum TraversalMethods
	{
		Preorder,
		Inorder,
		Postorder		
	}
}
