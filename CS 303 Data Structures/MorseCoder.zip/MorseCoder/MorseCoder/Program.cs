﻿using System;
using System.IO;
using skmDataStructures;
using skmDataStructures.BinaryTree;

namespace MorseCoder {
    class Program {
        static void Main(string[] args) {
            StreamReader reader = new StreamReader("MorseCodes.csv");
            MorseTree tree = new MorseTree(reader);

            //simple line using all alphabetical chars
            Console.WriteLine("the quick brown fox jumps over the lazy dog");
            //simple line as morse code
            Console.WriteLine(tree.Encode("the quick brown fox jumps over the lazy dog"));
            //simple line as morse code and back as english
            Console.WriteLine(tree.Decode(tree.Encode("the quick brown fox jumps over " 
                + "the lazy dog")));
          
            //hello world for testing capital letters and punctuation
            Console.WriteLine("Hello World. How are you?");
            //hello world as morse code
            Console.WriteLine(tree.Encode("Hello World. How are you?"));
            //hello world as morse code and back as lower-case english with no punctuation
            Console.WriteLine(tree.Decode(tree.Encode("Hello World. How are you?")));

            //should output "yoshi"
            Console.WriteLine(tree.Decode("-*-- --- *** **** **")); //Yoshi!
        }
    }
}