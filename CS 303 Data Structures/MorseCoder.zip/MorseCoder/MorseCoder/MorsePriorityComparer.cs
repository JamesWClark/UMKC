﻿using System;
using System.Collections;
namespace MorseCoder {
    /// <summary>
    /// Compare string lengths. Longer strings evaluate less than shorter strings.
    /// </summary>
    class MorsePriorityComparer : IComparer {
        //compare by string length
        public int Compare(Object x, Object y) {
            if (x.ToString().Length == y.ToString().Length) //equality
                return 0;
            else if (x.ToString().Length < y.ToString().Length) //shortest length is max value 
                return 1;
            else //longest length is least value
                return -1;
        }
    }
}
