﻿// This Heap class is adapted to C# from C++ source in Dr. Mohammad Kuhail's Lecture 17 - Heaps
using System;
using System.Collections;
using System.Collections.Generic;
namespace MorseCoder {
    /// <summary>
    /// A generic List based Heap implementation.
    /// </summary>
    /// <remarks>Use an IComparer interface to build a Min or custom ordered Heap.</remarks>
    /// <typeparam name="T"></typeparam>
    class Heap<T> {
        //heap data is stored in this List
        private List<IComparable> data = new List<IComparable>();
        private IComparer comparer = null;
        /// <summary>
        /// The default Heap constructor.
        /// </summary>
        public Heap() {

        }
        /// <summary>
        /// Construct a Heap object that uses a custom comparer.
        /// </summary>
        /// <remarks>Useful</remarks>
        /// <param name="comparer"></param>
        public Heap(IComparer comparer) {
            this.comparer = comparer;
        }
        /// <summary>
        /// Insert any object that imlements the IComparable interface.
        /// </summary>
        /// <param name="generic"></param>
        /// <remarks>For custom comparison, construct with IComparer interface</remarks>
        public void Insert(IComparable generic) {
            data.Insert(data.Count, generic);
            int child = data.Count - 1;
            int parent = (child - 1) / 2;

            if (comparer == null) { //compare without a comparer
                while (child > 0 && data[parent].CompareTo(generic) < 0) {
                    IComparable temp = data[child]; //swap
                    data[child] = data[parent];
                    data[parent] = temp;
                    child = parent;
                    parent = (child - 1) / 2;
                }
            } else { //use the provided comparer
                while (child > 0 && comparer.Compare(data[parent], generic) < 0) {
                    IComparable temp = data[child]; //swap
                    data[child] = data[parent];
                    data[parent] = temp;
                    child = parent;
                    parent = (child - 1) / 2;
                }
            }
        }
        /// <summary>
        /// Remove and return the top of the heap. Restores heapness.
        /// </summary>
        /// <returns>IComparable node</returns>
        public IComparable Remove() {
            IComparable returnNode = null;
            if (data.Count == 1) {
                returnNode = data[0]; //set the return node
                data.RemoveAt(0);
                return returnNode;
            }
            IComparable temp = data[0];
            data[0] = data[data.Count - 1];
            data[data.Count - 1] = temp;
            returnNode = data[data.Count - 1]; //set the return
            data.RemoveAt(data.Count - 1);
            int parent = 0;
            int leftChild = 2 * parent + 1;

            while (true) {
                leftChild = 2 * parent + 1;
                if (leftChild >= data.Count) {
                    break;
                }
                int rightChild = leftChild + 1;
                int maxChild = leftChild;
                if (comparer == null) { //use default CompareTo method of generic object
                    if (rightChild < data.Count 
                            && data[leftChild].CompareTo(data[rightChild]) < 0) {
                        maxChild = rightChild;
                    }
                    if (data[parent].CompareTo(data[maxChild]) < 0) {
                        //swap parent and child
                        IComparable temp2 = data[maxChild];
                        data[maxChild] = data[parent];
                        data[parent] = temp2;
                        parent = maxChild;
                    } else {
                        break;
                    }
                } else { //use the provided custom comparer
                    if (rightChild < data.Count 
                            && comparer.Compare(data[leftChild], data[rightChild]) < 0) {
                        maxChild = rightChild;
                    }
                    if (comparer.Compare(data[parent], data[maxChild]) < 0) {
                        IComparable temp2 = data[maxChild];
                        data[maxChild] = data[parent];
                        data[parent] = temp2;
                        parent = maxChild;
                    } else {
                        break;
                    }
                }
            }
            return returnNode;
        }
        /// <summary>
        /// The number of items in the Heap
        /// </summary>
        public int Count {
            get {
                return data.Count;
            }
        }
        /// <summary>
        /// Read-only access to the custom comparer.
        /// </summary>
        public IComparer Comparer {
            get {
                return this.comparer;
            }
        }
    }
}
