﻿using System;
using System.IO;
using System.Text;
using skmDataStructures.BinaryTree;

namespace MorseCoder {
    /// <summary>
    /// The MorseTree class inherits BinaryTree
    /// </summary>
    public class MorseTree : BinaryTree {
        //use heap as priority queue, construct with custom string comparer (min heap on string length)
        private static MorsePriorityComparer comparer = new MorsePriorityComparer();
        private Heap<string> heap = new Heap<string>(comparer);
        /// <summary>
        /// Build a MorseTree by traversing a code to insert a letter.
        /// </summary>
        /// <param name="letter">the decoded character</param>
        /// <param name="code">the encoded string</param>
        private void Insert(char letter, string code) {
            Node node = this.Root;
            foreach (char c in code) {
                //dot left
                if (c == '*') {
                    //insert at empty location
                    if (node.Left == null) {
                        node.Left = new Node(letter);
                        break;
                    }
                    //traverse left
                    node = node.Left;
                }
                //dash right
                if (c == '-') {
                    //insert at empty location
                    if (node.Right == null) {
                        node.Right = new Node(letter);
                        break;
                    }
                    //traverse right
                    node = node.Right;
                }
            }
        }
        /// <summary>
        /// Encode a string of characters to its morse code representation.
        /// </summary>
        /// <param name="text">The text to encode. Supports letters and digits.</param>
        /// <returns>Returns Morse encoded text</returns>
        public string Encode(string text) {
            string morse = "";
            //consider every character in the text
            foreach (char ch in text) {
                if (char.IsLetterOrDigit(ch)) {
                    //add equivilant morse code, followed by space
                    string temp = Encode(char.ToLower(ch), Root, "");
                    if (temp == "\0") //failed search
                        throw new Exception("Cannot find equivilant morse code for "
                            + ch + ", tree was improperly built.");
                    morse += temp + Root.Value;
                } else if (ch == ' ') {
                    morse += Root.Value;
                    morse += Root.Value; //now it should have three spaces in a row
                }
                //else ignore the character
            }
            return morse;
        }
        /// <summary>
        /// Encode a letter to its Morse code
        /// </summary>
        /// <param name="ch">The letter to encode</param>
        /// <param name="root">The current node to search</param>
        /// <param name="morse">The encoded string to return</param>
        /// <returns>A Morse encoded string</returns>
        private string Encode(char ch, Node root, string morse) {
            //if chars match up, return current node's position
            if (ch == (char)root.Value)
                return morse;
            //else search by preorder
            string temp = "\0";
            if (root.Left != null)
                temp = Encode(ch, root.Left, morse + '*'); //check left
            if (temp != "\0")
                return temp; //will return the morse from searching to the left
            else if (root.Right != null)
                temp = Encode(ch, root.Right, morse + '-'); //check right
            //is either morse from searching to the right, or \0 marking failure
            return temp;
        }
        /// <summary>
        /// Decode a Morse code to reveal its letter
        /// </summary>
        /// <param name="morse">The Morse code to decode</param>
        /// <returns>A decoded letter</returns>
        public string Decode(string morse) {
            string text = "";
            string ch = "";
            while (morse != "" || ch != "") {
                if (morse != "" && !char.IsWhiteSpace(morse[0]))
                    ch += morse[0]; //hold onto this morse character
                else { //is whitespace
                    //currently holding morse characters, space between characters
                    if (ch != "") {
                        Node temp = Root;
                        while (ch != "") { //still holding morse characters
                            //go left, astrisk and dot, just in case
                            if (ch[0] == '*' || ch[0] == '•')
                                temp = temp.Left;
                            //go right, two different common kinds of dashes
                            else if (ch[0] == '–' || ch[0] == '-')
                                temp = temp.Right;
                            else
                                throw new Exception("Received invalid morse code string. "
                                    + "Check for possible spies.\n String so far: "
                                    + text + '\n');
                            ch = ch.Substring(1); //chop off the front morse character
                        }
                        //not holding characters, give them the current node
                        text += temp.Value;
                    } else {//not holding characters, spaces between words
                        //chop off upcoming whitespace characters
                        morse = morse.Trim();
                        //add the character at the top of the tree
                        text += this.Root.Value;
                        //don't chop off a character, we just chopped off a few
                        continue;
                    }
                }
                //don't cut an empty string
                if (morse != "")
                    //chop off the front character, we're done with it
                    morse = morse.Substring(1);
            }
            return text;
        }
        /// <summary>
        /// Construct a Morse Huffman Tree from file contents
        /// </summary>
        /// <param name="file">Format: CSV file as letter, code such as a,-*</param>
        public MorseTree(StreamReader reader) {
            PriorityQueueAll(reader);
            BuildMorseTree();
        }
        /// <summary>
        /// Read codes from a file and insert into a heap.
        /// </summary>
        /// <param name="reader">The reader is provided in the MorseTree constructor</param>
        private void PriorityQueueAll(StreamReader reader) {
            //read codes from a file, insert into heap queue
            while (!reader.EndOfStream) {
                string data = reader.ReadLine();
                heap.Insert(data);
            }
        }
        /// <summary>
        /// Construct the MorseTree.
        /// </summary>
        /// <remarks>Call this method after PriorityQueueAll()</remarks>
        private void BuildMorseTree() {
            //root node is the space character
            this.Root = new Node(' ');
            //while priority queue has items do
            while (heap.Count > 0) {
                string data = heap.Remove() as string;
                //newline in file will be string.empty
                //newline characters are ignored
                //the root is already created for space characters
                if (data != string.Empty) {
                    //separate CSV data
                    string[] split = data.Split(',');
                    //first character in first data is a letter
                    char letter = split[0][0];
                    //second data is the code
                    string code = split[1];
                    //insert method uses code to traverse and insert a letter.
                    //priority queue enables tree shape integrity
                    this.Insert(letter, code);
                }
            }
        }
        /// <summary>
        /// Print the tree by recursive inorder traversal.
        /// </summary>
        /// <param name="current">The current node during a traversal step.</param>
        /// <param name="separator">A separator to place between values when printing.</param>
        /// <returns></returns>
        public string InorderTraversal(Node current, string separator) {
            if (current != null) {
                StringBuilder sb = new StringBuilder();
                sb.Append(InorderTraversal(current.Left, separator));
                sb.Append(current.Value.ToString());
                sb.Append(separator);
                sb.Append(InorderTraversal(current.Right, separator));
                return sb.ToString();
            } else
                return String.Empty;
        }
    }
}
