﻿using System;
using System.Collections.Generic;

namespace Sandbox {
    class Program {
        static void Main(string[] args) {
            Dictionary<Guid, int> stuff = new Dictionary<Guid, int>();
            stuff.Add(Guid.NewGuid(), 3);
            stuff.Add(Guid.NewGuid(), 1);
            stuff.Add(Guid.NewGuid(), 12);
        }
    }
}