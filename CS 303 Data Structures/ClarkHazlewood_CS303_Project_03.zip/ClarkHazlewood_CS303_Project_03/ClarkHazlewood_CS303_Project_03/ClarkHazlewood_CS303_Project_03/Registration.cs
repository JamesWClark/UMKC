﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ClarkHazlewood_CS303_Project_03 {
    public partial class Registration : Form {

        #region PROPERTIES

        private Registrar registrar = Program.Registrar;
        private bool student_editMode = false;
        private bool course_editMode = false;

        #endregion

        public Registration() {
            InitializeComponent();
        }

        #region EVENT HANDLERS

        /// <summary>
        /// The Form is loaded when the application runs
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Registration_Load(object sender, EventArgs e) {
            SetDemoData();
            UI_BindSources();
            UI_RegisterHandlers();
        }
        /// <summary>
        /// A combo box item is selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ComboBox_SelectedIndexChanged(object sender, EventArgs e) {
            UI_HideMessage();
            UI_DeregisterHandlers();

            ComboBox cb = sender as ComboBox;
            switch (cb.Name) {
                case "cbStudents":
                    Guid studentID = new Guid(cbStudents.SelectedValue.ToString());
                    Student student = registrar.Students[studentID];
                    txtStudentID.Text = student.StudentID.ToString();
                    txtStudentFirstName.Text = student.FirstName;
                    txtStudentLastName.Text = student.LastName;
                    UI_Student_BindSchedule(registrar.Student_ViewSchedule(studentID));
                    break;
                case "cbCourses":
                    Guid courseID = new Guid(cbCourses.SelectedValue.ToString());
                    Course course = registrar.Courses[courseID];
                    txtCourseID.Text = course.CourseID.ToString();
                    txtCourseTitle.Text = course.Title;
                    UI_Course_BindRoster(registrar.Course_ViewRoster(courseID));
                    break;
                case "cbEnrollments":
                    Guid enrollmentID = new Guid(cbEnrollments.SelectedValue.ToString());
                    Enrollment enrollment = registrar.Enrollments[enrollmentID];
                    txtEnrollmentID.Text = enrollment.EnrollmentID.ToString();
                    txtEnrollmentStudentID.Text = enrollment.StudentID.ToString();
                    txtEnrollmentCourseID.Text = enrollment.CourseID.ToString();
                    txtEnrollmentDate.Text = enrollment.EnrollmentDate.ToString();
                    break;
            }

            UI_UpdateState();
            UI_RegisterHandlers();
        }
        /// <summary>
        /// Content in a text box is changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TextBox_TextChanged(object sender, EventArgs e) {
            UI_HideMessage();
            TextBox t = sender as TextBox;
            switch (t.Name) {
                case "txtStudentFirstName":
                case "txtStudentLastName":
                    student_editMode = true;
                    break;
                case "txtCourseTitle":
                    course_editMode = true;
                    break;
            }
        }
        /// <summary>
        /// Clear button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Clear_Click(object sender, EventArgs e) {
            UI_HideMessage();

            Button b = sender as Button;
            switch (b.Name) {
                case "btnStudent_Clear":
                    UI_Student_Clear();
                    break;
                case "btnCourse_Clear":
                    UI_Course_Clear();
                    break;
            }
        }
        /// <summary>
        /// Save button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Save_Click(object sender, EventArgs e) {
            Button b = sender as Button;
            switch (b.Name) {
                case "btnStudent_Save":
                    if (txtStudentID.Text == String.Empty) {
                        registrar.Student_Add(txtStudentFirstName.Text, txtStudentLastName.Text);
                        UI_ShowMessage("Student Added");
                    } else {
                        registrar.Student_Edit(new Guid(txtStudentID.Text), txtStudentFirstName.Text, txtStudentLastName.Text);
                        UI_ShowMessage("Student Updated");
                    }
                    break;
                case "btnCourse_Save":
                    if (txtCourseID.Text == String.Empty) {
                        registrar.Course_Add(txtCourseTitle.Text);
                        UI_ShowMessage("Course Added");
                    } else {
                        registrar.Course_Edit(new Guid(txtCourseID.Text), txtCourseTitle.Text);
                        UI_ShowMessage("Course Updated");
                    }
                    break;
            }
            UI_DeregisterHandlers();
            UI_BindSources();
            UI_RegisterHandlers();
        }
        /// <summary>
        /// Delete button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Delete_Click(object sender, EventArgs e) {
            Button b = sender as Button;
            switch (b.Name) {
                case "btnStudent_Delete":
                    registrar.Student_Remove(new Guid(txtStudentID.Text));
                    UI_Student_Clear();
                    UI_ShowMessage("Student Deleted");
                    break;
                case "btnCourse_Delete":
                    registrar.Course_Remove(new Guid(txtCourseID.Text));
                    UI_Course_Clear();
                    pnlStudent_Schedule.Controls.Clear();
                    UI_ShowMessage("Course Deleted");
                    break;
            }
            UI_DeregisterHandlers();
            UI_BindSources();
            UI_RegisterHandlers();
        }
        /// <summary>
        /// Drop course link is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Registration_LinkButton_Click(object sender, EventArgs e) {
            UI_DeregisterHandlers();
            LinkLabel l = sender as LinkLabel;
            Guid courseID = new Guid(l.ImageKey);
            Guid studentID = new Guid(txtStudentID.Text);
            registrar.Withdraw_Course(studentID, courseID);
            UI_BindEnrollment();
            UI_Student_BindSchedule(registrar.Student_ViewSchedule(studentID));
            if (txtCourseID.Text != String.Empty) {
                UI_Course_BindRoster(registrar.Course_ViewRoster(new Guid(txtCourseID.Text)));
            }
            UI_ShowMessage("Course Dropped");
            UI_RegisterHandlers();
        }
        /// <summary>
        /// Course Register button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRegister_Click(object sender, EventArgs e) {
            UI_DeregisterHandlers();

            Guid studentID = new Guid(txtStudentID.Text);
            Guid courseID = new Guid(txtCourseID.Text);

            try {
                registrar.Enroll_Course(studentID, courseID);
                UI_ShowMessage("Course Added");
                UI_Student_BindSchedule(registrar.Student_ViewSchedule(studentID));
                UI_Course_BindRoster(registrar.Course_ViewRoster(courseID));
                UI_BindEnrollment();
            } catch (Exception ex) {
                UI_ShowError(ex.Message);
            }

            UI_RegisterHandlers();
        }
        /// <summary>
        /// The state of the form is changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void State_Change(object sender, EventArgs e) {
            if (sender.GetType() == typeof(Button)) {
                student_editMode = false;
                course_editMode = false;
            }
            UI_UpdateState();
        }

        #endregion

        #region USER INTERFACE MANAGEMENT METHODS

        /// <summary>
        /// Binds the Student, Course, and Enrollment dictionaries to relevant form controls
        /// </summary>
        private void UI_BindSources() {
            if (registrar.Students.Count > 0) {
                cbStudents.DataSource = new BindingSource(registrar.Students, null);
                cbStudents.DisplayMember = "Value";
                cbStudents.ValueMember = "Key";
            } else {
                cbStudents.DataSource = null;
            }
            if (registrar.Courses.Count > 0) {
                cbCourses.DataSource = new BindingSource(registrar.Courses, null);
                cbCourses.DisplayMember = "Value";
                cbCourses.ValueMember = "Key";
            } else {
                cbCourses.DataSource = null;
            }
            
            UI_BindEnrollment();
            
        }
        /// <summary>
        /// Binds the Enrollment dictionary
        /// </summary>
        private void UI_BindEnrollment() {
            if (registrar.Enrollments.Count > 0) {
                cbEnrollments.DataSource = new BindingSource(registrar.Enrollments, null);
                cbEnrollments.DisplayMember = "Value";
                cbEnrollments.ValueMember = "Key";
            } else {
                cbEnrollments.DataSource = null;
            }
        }
        /// <summary>
        /// Registers combo box, text box, and state change events to relevant form controls
        /// </summary>
        private void UI_RegisterHandlers() {
            cbStudents.SelectedIndexChanged += new EventHandler(ComboBox_SelectedIndexChanged);
            cbCourses.SelectedIndexChanged += new EventHandler(ComboBox_SelectedIndexChanged);
            cbEnrollments.SelectedIndexChanged += new EventHandler(ComboBox_SelectedIndexChanged);
            txtStudentFirstName.TextChanged += new EventHandler(TextBox_TextChanged);
            txtStudentLastName.TextChanged += new EventHandler(TextBox_TextChanged);
            txtCourseTitle.TextChanged += new EventHandler(TextBox_TextChanged);

            btnStudent_Clear.Click += new EventHandler(State_Change);
            btnStudent_Save.Click += new EventHandler(State_Change);
            btnStudent_Delete.Click += new EventHandler(State_Change);
            btnCourse_Clear.Click += new EventHandler(State_Change);
            btnCourse_Save.Click += new EventHandler(State_Change);
            btnStudent_Delete.Click += new EventHandler(State_Change);
            
        }
        /// <summary>
        /// Deregisters handlers from relevant controls.
        /// </summary>
        /// <remarks>This is used to prevent additional firing of events.</remarks>
        private void UI_DeregisterHandlers() {
            cbStudents.SelectedIndexChanged -= new EventHandler(ComboBox_SelectedIndexChanged);
            cbCourses.SelectedIndexChanged -= new EventHandler(ComboBox_SelectedIndexChanged);
            cbEnrollments.SelectedIndexChanged -= new EventHandler(ComboBox_SelectedIndexChanged);
            txtStudentFirstName.TextChanged -= new EventHandler(TextBox_TextChanged);
            txtStudentLastName.TextChanged -= new EventHandler(TextBox_TextChanged);
            txtCourseTitle.TextChanged -= new EventHandler(TextBox_TextChanged);

            btnStudent_Clear.Click -= new EventHandler(State_Change);
            btnStudent_Save.Click -= new EventHandler(State_Change);
            btnStudent_Delete.Click -= new EventHandler(State_Change);
            btnCourse_Clear.Click -= new EventHandler(State_Change);
            btnCourse_Save.Click -= new EventHandler(State_Change);
            btnStudent_Delete.Click -= new EventHandler(State_Change);
        }
        /// <summary>
        /// Enables and disables controls depending on the state of the form
        /// </summary>
        private void UI_UpdateState() {
            //student is currently selected
            if (txtStudentID.Text != String.Empty) {
                btnStudent_Clear.Enabled = true;
                btnStudent_Delete.Enabled = true;
                btnStudent_Save.Text = "Update Student";
            } else {
                btnStudent_Clear.Enabled = false;
                btnStudent_Delete.Enabled = false;
                btnStudent_Save.Text = "Save Student";
            }
            //course is currently selected
            if (txtCourseID.Text != String.Empty) {
                btnCourse_Clear.Enabled = true;
                btnCourse_Delete.Enabled = true;
                btnCourse_Save.Text = "Update Course";
            } else {
                btnCourse_Clear.Enabled = false;
                btnCourse_Delete.Enabled = false;
                btnCourse_Save.Text = "Save Course";
            }
            //student and course are selected
            if (txtStudentID.Text != String.Empty && txtCourseID.Text != String.Empty) {
                btnRegister.Enabled = true;
            } else {
                btnRegister.Enabled = false;
            }
            //edit modes
            if (student_editMode) {
                btnStudent_Save.Enabled = true;
            } else {
                btnStudent_Save.Enabled = false;
            }
            if (course_editMode) {
                btnCourse_Save.Enabled = true;
            } else {
                btnCourse_Save.Enabled = false;
            }
        }
        /// <summary>
        /// Displays a message with a green background
        /// </summary>
        /// <param name="message"></param>
        private void UI_ShowMessage(string message) {
            txtMessage.BackColor = Color.LimeGreen;
            txtMessage.ForeColor = Color.Black;
            txtMessage.Text = message;
            txtMessage.Visible = true;
        }
        /// <summary>
        /// Displays an error message with a red background
        /// </summary>
        /// <param name="error"></param>
        private void UI_ShowError(string error) {
            txtMessage.BackColor = Color.Red;
            txtMessage.ForeColor = Color.White;
            txtMessage.Text = error;
            txtMessage.Visible = true;
        }
        /// <summary>
        /// Hides the message box when not in use
        /// </summary>
        private void UI_HideMessage() {
            txtMessage.Visible = false;
            txtMessage.Text = String.Empty;
        }
        /// <summary>
        /// Updates the student schedule
        /// </summary>
        /// <param name="schedule"></param>
        private void UI_Student_BindSchedule(HashSet<Course> schedule) {
            if (txtStudentID.Text != String.Empty) {
                pnlStudent_Schedule.Controls.Clear();
                Student student = registrar.Students[new Guid(txtStudentID.Text)];
                TableLayoutPanel table = new TableLayoutPanel();

                int count = 0;
                foreach (Course c in schedule) {
                    LinkLabel link = new LinkLabel();
                    link.Text = "Drop";
                    link.ImageKey = c.CourseID.ToString();
                    link.Click += new EventHandler(Registration_LinkButton_Click);
                    Label label = new Label();
                    label.Text = c.Title;

                    table.Controls.Add(link);
                    table.Controls.Add(label);
                    table.SetColumn(link, 0);
                    table.SetColumn(label, 1);
                    table.SetRow(link, count);
                    table.SetRow(label, count);
                    count++;

                }

                pnlStudent_Schedule.Controls.Add(table);
            }
        }
        /// <summary>
        /// Updates the course roster
        /// </summary>
        /// <param name="roster"></param>
        private void UI_Course_BindRoster(HashSet<Student> roster) {
            lvCourse_Roster.Items.Clear();
            foreach (Student student in roster) {
                ListViewItem item = new ListViewItem();
                item.Text = student.LastName + ", " + student.FirstName;
                item.ImageKey = student.StudentID.ToString();
                lvCourse_Roster.Items.Add(item);
            }
        }
        /// <summary>
        /// Clears student controls' data
        /// </summary>
        private void UI_Student_Clear() {
            UI_DeregisterHandlers();
            txtStudentID.Text = String.Empty;
            txtStudentFirstName.Text = String.Empty;
            txtStudentLastName.Text = String.Empty;
            pnlStudent_Schedule.Controls.Clear();
            UI_RegisterHandlers();
        }
        /// <summary>
        /// Clears course controls' data
        /// </summary>
        private void UI_Course_Clear() {
            UI_DeregisterHandlers();
            txtCourseID.Text = String.Empty;
            txtCourseTitle.Text = String.Empty;
            lvCourse_Roster.Items.Clear();
            UI_DeregisterHandlers();
        }
        /// <summary>
        /// Pre-loads the form with demonstration and testing data.
        /// </summary>
        private void SetDemoData() {
            //create some students and courses
            Course a = new Course("English 101");
            Course b = new Course("Math 300");
            Course c = new Course("Accounting 206");
            Student d = new Student("Jay", "Z");
            Student f = new Student("Bo", "Jackson");
            Student g = new Student("Snoop", "Lion");
            //add courses and students to registrar
            registrar.Courses.Add(a.CourseID, a);
            registrar.Courses.Add(b.CourseID, b);
            registrar.Courses.Add(c.CourseID, c);
            registrar.Students.Add(d.StudentID, d);
            registrar.Students.Add(f.StudentID, f);
            registrar.Students.Add(g.StudentID, g);
            registrar.Enroll_Course(f.StudentID, b.CourseID);
        }

        #endregion

    }
}
