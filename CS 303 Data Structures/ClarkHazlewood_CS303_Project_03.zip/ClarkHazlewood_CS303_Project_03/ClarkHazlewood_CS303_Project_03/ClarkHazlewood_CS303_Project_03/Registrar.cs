﻿using System;
using System.Collections.Generic;

namespace ClarkHazlewood_CS303_Project_03
{
  class Registrar
  {
    public Dictionary<Guid, Student> Students = new Dictionary<Guid, Student>();
    public Dictionary<Guid, Course> Courses = new Dictionary<Guid, Course>();
    public Dictionary<Guid, Enrollment> Enrollments = new Dictionary<Guid, Enrollment>();

    //Add new Students/Courses
    public void Student_Add(string firstName, string lastName)
    {
      Student NewStudent = new Student(firstName, lastName);
      Students.Add(NewStudent.StudentID, NewStudent);
    }
    public void Course_Add(string title)
    {
      Course NewCourse = new Course(title);
      Courses.Add(NewCourse.CourseID, NewCourse);
    }

    //Edit Students/Courses
    public void Student_Edit(Guid studentID, string newFirst, string newLast)
    {
      Student student = Students[studentID];
      student.FirstName = newFirst;
      student.LastName = newLast;
    }
    public void Course_Edit(Guid courseID, string newTitle)
    {
      Course course = Courses[courseID];
      course.Title = newTitle;
    }

    //Remove Students/Courses
    public void Student_Remove(Guid studentID)
    {
      HashSet<Course> enroll = Student_ViewSchedule(studentID);
      
      foreach (Course course in enroll) //first withdraw student from all courses
        Withdraw_Course(studentID, course.CourseID); //so there's no data remaining

      Students.Remove(studentID);
    }
    public void Course_Remove(Guid courseID)
    {
      HashSet<Student> enroll = Course_ViewRoster(courseID);

      foreach (Student student in enroll) //first withdraw students from this course
        Withdraw_Course(student.StudentID, courseID); //so there's no data remaining

      Courses.Remove(courseID);
    }

    //Enroll/Withdraw a Student from a Course
    public void Enroll_Course(Guid studentID, Guid courseID)
    {
      //first check to see if the student was already enrolled in the course
      HashSet<Course> enroll = Student_ViewSchedule(studentID);
      foreach (Course course in enroll)
      {
        if (course.CourseID == courseID) //a course matches the courseID
        {
          throw new Exception("Student is already enrolled in that course.");
          //return; //throw make this return unreachable!
        }
      }

      //no conflict found, proceed as normal
      Enrollment NewEnroll = new Enrollment(studentID, courseID);
      Enrollments.Add(NewEnroll.EnrollmentID,NewEnroll);
      Students[studentID].Enrollments.Add(NewEnroll);
      Courses[courseID].Enrollments.Add(NewEnroll);
    }
    public void Withdraw_Course(Guid studentID, Guid courseID) //student course method
    {
      bool removal = false;
      //Going to have to search either the Registrar's, Student's, or Course's enrollment set.
      //On average, the student will have the smallest set of the three, and has the smallest O(n)
      foreach (Enrollment enroll in Students[studentID].Enrollments)
      {
        if (enroll.CourseID == courseID)
        {
          Enrollments.Remove(enroll.EnrollmentID);
          Courses[courseID].Enrollments.Remove(enroll);
          Students[studentID].Enrollments.Remove(enroll);
          removal = true;
          break;
        }
      }
      if (!removal) //no removal made, throw an error back to the form.
        throw new Exception("Student was not enrolled in that course.");
    }
    /*
    public void Withdraw_Course(Guid enrollmentID) //enrollment method
    {
      Enrollments.Remove(enrollmentID);
    }
    */ 

    //View Schedule/Roster
    public HashSet<Course> Student_ViewSchedule(Guid studentID)
    {
      HashSet<Course> Schedule = new HashSet<Course>();

      foreach (Enrollment enroll in Students[studentID].Enrollments)
      {
        Schedule.Add(Courses[enroll.CourseID]);
      }

      return Schedule;
    }
    public HashSet<Student> Course_ViewRoster(Guid courseID)
    {
      HashSet<Student> Roster = new HashSet<Student>();

      foreach (Enrollment enroll in Courses[courseID].Enrollments)
      {
        Roster.Add(Students[enroll.StudentID]);
      }

      return Roster;
    }

  }
}
