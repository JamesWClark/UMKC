﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ClarkHazlewood_CS303_Project_03 {
    static class Program {
        public static Registrar Registrar = new Registrar();
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Registration());
        }
    }
}
