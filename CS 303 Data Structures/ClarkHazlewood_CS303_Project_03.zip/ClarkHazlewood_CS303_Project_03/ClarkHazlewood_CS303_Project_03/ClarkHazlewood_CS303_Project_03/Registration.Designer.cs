﻿namespace ClarkHazlewood_CS303_Project_03 {
    partial class Registration {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.cbStudents = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbCourses = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbEnrollments = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.txtStudentFirstName = new System.Windows.Forms.TextBox();
            this.txtStudentID = new System.Windows.Forms.TextBox();
            this.lblStudentID = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.txtStudentLastName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.btnStudent_Save = new System.Windows.Forms.Button();
            this.btnStudent_Clear = new System.Windows.Forms.Button();
            this.txtCourseID = new System.Windows.Forms.TextBox();
            this.lblCourseID = new System.Windows.Forms.Label();
            this.lblCourseTitle = new System.Windows.Forms.Label();
            this.lblEnrollmentID = new System.Windows.Forms.Label();
            this.txtCourseTitle = new System.Windows.Forms.TextBox();
            this.txtEnrollmentID = new System.Windows.Forms.TextBox();
            this.lblEnrollmentStudentID = new System.Windows.Forms.Label();
            this.btnCourse_Save = new System.Windows.Forms.Button();
            this.btnCourse_Clear = new System.Windows.Forms.Button();
            this.txtEnrollmentStudentID = new System.Windows.Forms.TextBox();
            this.lblEnrollmentCourseID = new System.Windows.Forms.Label();
            this.txtEnrollmentCourseID = new System.Windows.Forms.TextBox();
            this.lblEnrollmentDate = new System.Windows.Forms.Label();
            this.txtEnrollmentDate = new System.Windows.Forms.TextBox();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnStudent_Delete = new System.Windows.Forms.Button();
            this.btnCourse_Delete = new System.Windows.Forms.Button();
            this.pnlStudent_Schedule = new System.Windows.Forms.Panel();
            this.lvCourse_Roster = new System.Windows.Forms.ListView();
            this.lblCourseRoster = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cbStudents
            // 
            this.cbStudents.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.cbStudents.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cbStudents.FormattingEnabled = true;
            this.cbStudents.Location = new System.Drawing.Point(11, 25);
            this.cbStudents.Name = "cbStudents";
            this.cbStudents.Size = new System.Drawing.Size(250, 21);
            this.cbStudents.TabIndex = 0;
            this.cbStudents.SelectedIndexChanged += new System.EventHandler(this.State_Change);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Students";
            // 
            // cbCourses
            // 
            this.cbCourses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.cbCourses.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cbCourses.FormattingEnabled = true;
            this.cbCourses.Location = new System.Drawing.Point(267, 25);
            this.cbCourses.Name = "cbCourses";
            this.cbCourses.Size = new System.Drawing.Size(250, 21);
            this.cbCourses.TabIndex = 2;
            this.cbCourses.SelectedIndexChanged += new System.EventHandler(this.State_Change);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(267, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Courses";
            // 
            // cbEnrollments
            // 
            this.cbEnrollments.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.cbEnrollments.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cbEnrollments.FormattingEnabled = true;
            this.cbEnrollments.Location = new System.Drawing.Point(523, 25);
            this.cbEnrollments.Name = "cbEnrollments";
            this.cbEnrollments.Size = new System.Drawing.Size(250, 21);
            this.cbEnrollments.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(523, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Enrollments";
            // 
            // txtMessage
            // 
            this.txtMessage.BackColor = System.Drawing.Color.Red;
            this.txtMessage.ForeColor = System.Drawing.Color.White;
            this.txtMessage.Location = new System.Drawing.Point(11, 530);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.ReadOnly = true;
            this.txtMessage.Size = new System.Drawing.Size(759, 20);
            this.txtMessage.TabIndex = 9;
            this.txtMessage.Visible = false;
            // 
            // txtStudentFirstName
            // 
            this.txtStudentFirstName.Location = new System.Drawing.Point(81, 135);
            this.txtStudentFirstName.Name = "txtStudentFirstName";
            this.txtStudentFirstName.Size = new System.Drawing.Size(180, 20);
            this.txtStudentFirstName.TabIndex = 10;
            this.txtStudentFirstName.TextChanged += new System.EventHandler(this.State_Change);
            // 
            // txtStudentID
            // 
            this.txtStudentID.Location = new System.Drawing.Point(11, 109);
            this.txtStudentID.Name = "txtStudentID";
            this.txtStudentID.ReadOnly = true;
            this.txtStudentID.Size = new System.Drawing.Size(250, 20);
            this.txtStudentID.TabIndex = 11;
            // 
            // lblStudentID
            // 
            this.lblStudentID.AutoSize = true;
            this.lblStudentID.Location = new System.Drawing.Point(12, 93);
            this.lblStudentID.Name = "lblStudentID";
            this.lblStudentID.Size = new System.Drawing.Size(64, 13);
            this.lblStudentID.TabIndex = 12;
            this.lblStudentID.Text = "Student ID: ";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(12, 138);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(63, 13);
            this.lblFirstName.TabIndex = 13;
            this.lblFirstName.Text = "First Name: ";
            // 
            // txtStudentLastName
            // 
            this.txtStudentLastName.Location = new System.Drawing.Point(81, 161);
            this.txtStudentLastName.Name = "txtStudentLastName";
            this.txtStudentLastName.Size = new System.Drawing.Size(180, 20);
            this.txtStudentLastName.TabIndex = 14;
            this.txtStudentLastName.TextChanged += new System.EventHandler(this.State_Change);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(12, 164);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(64, 13);
            this.lblLastName.TabIndex = 15;
            this.lblLastName.Text = "Last Name: ";
            // 
            // btnStudent_Save
            // 
            this.btnStudent_Save.Enabled = false;
            this.btnStudent_Save.Location = new System.Drawing.Point(82, 187);
            this.btnStudent_Save.Name = "btnStudent_Save";
            this.btnStudent_Save.Size = new System.Drawing.Size(100, 23);
            this.btnStudent_Save.TabIndex = 16;
            this.btnStudent_Save.Text = "Save Student";
            this.btnStudent_Save.UseVisualStyleBackColor = true;
            this.btnStudent_Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // btnStudent_Clear
            // 
            this.btnStudent_Clear.Enabled = false;
            this.btnStudent_Clear.Location = new System.Drawing.Point(188, 187);
            this.btnStudent_Clear.Name = "btnStudent_Clear";
            this.btnStudent_Clear.Size = new System.Drawing.Size(75, 23);
            this.btnStudent_Clear.TabIndex = 17;
            this.btnStudent_Clear.Text = "Clear";
            this.btnStudent_Clear.UseVisualStyleBackColor = true;
            this.btnStudent_Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // txtCourseID
            // 
            this.txtCourseID.Location = new System.Drawing.Point(267, 109);
            this.txtCourseID.Name = "txtCourseID";
            this.txtCourseID.ReadOnly = true;
            this.txtCourseID.Size = new System.Drawing.Size(250, 20);
            this.txtCourseID.TabIndex = 18;
            // 
            // lblCourseID
            // 
            this.lblCourseID.AutoSize = true;
            this.lblCourseID.Location = new System.Drawing.Point(267, 93);
            this.lblCourseID.Name = "lblCourseID";
            this.lblCourseID.Size = new System.Drawing.Size(57, 13);
            this.lblCourseID.TabIndex = 19;
            this.lblCourseID.Text = "Course ID:";
            // 
            // lblCourseTitle
            // 
            this.lblCourseTitle.AutoSize = true;
            this.lblCourseTitle.Location = new System.Drawing.Point(267, 138);
            this.lblCourseTitle.Name = "lblCourseTitle";
            this.lblCourseTitle.Size = new System.Drawing.Size(69, 13);
            this.lblCourseTitle.TabIndex = 20;
            this.lblCourseTitle.Text = "Course Title: ";
            // 
            // lblEnrollmentID
            // 
            this.lblEnrollmentID.AutoSize = true;
            this.lblEnrollmentID.Location = new System.Drawing.Point(523, 93);
            this.lblEnrollmentID.Name = "lblEnrollmentID";
            this.lblEnrollmentID.Size = new System.Drawing.Size(76, 13);
            this.lblEnrollmentID.TabIndex = 21;
            this.lblEnrollmentID.Text = "Enrollment ID: ";
            // 
            // txtCourseTitle
            // 
            this.txtCourseTitle.Location = new System.Drawing.Point(336, 135);
            this.txtCourseTitle.Name = "txtCourseTitle";
            this.txtCourseTitle.Size = new System.Drawing.Size(181, 20);
            this.txtCourseTitle.TabIndex = 22;
            this.txtCourseTitle.TextChanged += new System.EventHandler(this.State_Change);
            // 
            // txtEnrollmentID
            // 
            this.txtEnrollmentID.Location = new System.Drawing.Point(523, 109);
            this.txtEnrollmentID.Name = "txtEnrollmentID";
            this.txtEnrollmentID.ReadOnly = true;
            this.txtEnrollmentID.Size = new System.Drawing.Size(250, 20);
            this.txtEnrollmentID.TabIndex = 23;
            // 
            // lblEnrollmentStudentID
            // 
            this.lblEnrollmentStudentID.AutoSize = true;
            this.lblEnrollmentStudentID.Location = new System.Drawing.Point(523, 138);
            this.lblEnrollmentStudentID.Name = "lblEnrollmentStudentID";
            this.lblEnrollmentStudentID.Size = new System.Drawing.Size(64, 13);
            this.lblEnrollmentStudentID.TabIndex = 24;
            this.lblEnrollmentStudentID.Text = "Student ID: ";
            // 
            // btnCourse_Save
            // 
            this.btnCourse_Save.Enabled = false;
            this.btnCourse_Save.Location = new System.Drawing.Point(336, 161);
            this.btnCourse_Save.Name = "btnCourse_Save";
            this.btnCourse_Save.Size = new System.Drawing.Size(100, 23);
            this.btnCourse_Save.TabIndex = 27;
            this.btnCourse_Save.Text = "Save Course";
            this.btnCourse_Save.UseVisualStyleBackColor = true;
            this.btnCourse_Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // btnCourse_Clear
            // 
            this.btnCourse_Clear.Enabled = false;
            this.btnCourse_Clear.Location = new System.Drawing.Point(442, 161);
            this.btnCourse_Clear.Name = "btnCourse_Clear";
            this.btnCourse_Clear.Size = new System.Drawing.Size(75, 23);
            this.btnCourse_Clear.TabIndex = 28;
            this.btnCourse_Clear.Text = "Clear";
            this.btnCourse_Clear.UseVisualStyleBackColor = true;
            this.btnCourse_Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // txtEnrollmentStudentID
            // 
            this.txtEnrollmentStudentID.Location = new System.Drawing.Point(523, 154);
            this.txtEnrollmentStudentID.Name = "txtEnrollmentStudentID";
            this.txtEnrollmentStudentID.ReadOnly = true;
            this.txtEnrollmentStudentID.Size = new System.Drawing.Size(250, 20);
            this.txtEnrollmentStudentID.TabIndex = 29;
            // 
            // lblEnrollmentCourseID
            // 
            this.lblEnrollmentCourseID.AutoSize = true;
            this.lblEnrollmentCourseID.Location = new System.Drawing.Point(523, 177);
            this.lblEnrollmentCourseID.Name = "lblEnrollmentCourseID";
            this.lblEnrollmentCourseID.Size = new System.Drawing.Size(60, 13);
            this.lblEnrollmentCourseID.TabIndex = 30;
            this.lblEnrollmentCourseID.Text = "Course ID: ";
            // 
            // txtEnrollmentCourseID
            // 
            this.txtEnrollmentCourseID.Location = new System.Drawing.Point(523, 193);
            this.txtEnrollmentCourseID.Name = "txtEnrollmentCourseID";
            this.txtEnrollmentCourseID.ReadOnly = true;
            this.txtEnrollmentCourseID.Size = new System.Drawing.Size(250, 20);
            this.txtEnrollmentCourseID.TabIndex = 31;
            // 
            // lblEnrollmentDate
            // 
            this.lblEnrollmentDate.AutoSize = true;
            this.lblEnrollmentDate.Location = new System.Drawing.Point(523, 222);
            this.lblEnrollmentDate.Name = "lblEnrollmentDate";
            this.lblEnrollmentDate.Size = new System.Drawing.Size(88, 13);
            this.lblEnrollmentDate.TabIndex = 32;
            this.lblEnrollmentDate.Text = "Enrollment Date: ";
            // 
            // txtEnrollmentDate
            // 
            this.txtEnrollmentDate.Location = new System.Drawing.Point(617, 219);
            this.txtEnrollmentDate.Name = "txtEnrollmentDate";
            this.txtEnrollmentDate.ReadOnly = true;
            this.txtEnrollmentDate.Size = new System.Drawing.Size(156, 20);
            this.txtEnrollmentDate.TabIndex = 33;
            // 
            // btnRegister
            // 
            this.btnRegister.Enabled = false;
            this.btnRegister.Location = new System.Drawing.Point(11, 257);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(101, 23);
            this.btnRegister.TabIndex = 34;
            this.btnRegister.Text = "Register Course";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnStudent_Delete
            // 
            this.btnStudent_Delete.Enabled = false;
            this.btnStudent_Delete.Location = new System.Drawing.Point(81, 216);
            this.btnStudent_Delete.Name = "btnStudent_Delete";
            this.btnStudent_Delete.Size = new System.Drawing.Size(100, 23);
            this.btnStudent_Delete.TabIndex = 36;
            this.btnStudent_Delete.Text = "Delete Student";
            this.btnStudent_Delete.UseVisualStyleBackColor = true;
            this.btnStudent_Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // btnCourse_Delete
            // 
            this.btnCourse_Delete.Enabled = false;
            this.btnCourse_Delete.Location = new System.Drawing.Point(336, 191);
            this.btnCourse_Delete.Name = "btnCourse_Delete";
            this.btnCourse_Delete.Size = new System.Drawing.Size(100, 23);
            this.btnCourse_Delete.TabIndex = 37;
            this.btnCourse_Delete.Text = "Delete Course";
            this.btnCourse_Delete.UseVisualStyleBackColor = true;
            this.btnCourse_Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // pnlStudent_Schedule
            // 
            this.pnlStudent_Schedule.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlStudent_Schedule.Location = new System.Drawing.Point(11, 287);
            this.pnlStudent_Schedule.Name = "pnlStudent_Schedule";
            this.pnlStudent_Schedule.Size = new System.Drawing.Size(250, 237);
            this.pnlStudent_Schedule.TabIndex = 35;
            // 
            // lvCourse_Roster
            // 
            this.lvCourse_Roster.BackColor = System.Drawing.Color.Gainsboro;
            this.lvCourse_Roster.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvCourse_Roster.Location = new System.Drawing.Point(267, 287);
            this.lvCourse_Roster.Name = "lvCourse_Roster";
            this.lvCourse_Roster.Size = new System.Drawing.Size(250, 237);
            this.lvCourse_Roster.TabIndex = 38;
            this.lvCourse_Roster.UseCompatibleStateImageBehavior = false;
            this.lvCourse_Roster.View = System.Windows.Forms.View.List;
            // 
            // lblCourseRoster
            // 
            this.lblCourseRoster.AutoSize = true;
            this.lblCourseRoster.Location = new System.Drawing.Point(267, 268);
            this.lblCourseRoster.Name = "lblCourseRoster";
            this.lblCourseRoster.Size = new System.Drawing.Size(80, 13);
            this.lblCourseRoster.TabIndex = 39;
            this.lblCourseRoster.Text = "Course Roster: ";
            // 
            // Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.lblCourseRoster);
            this.Controls.Add(this.lvCourse_Roster);
            this.Controls.Add(this.btnCourse_Delete);
            this.Controls.Add(this.btnStudent_Delete);
            this.Controls.Add(this.pnlStudent_Schedule);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.txtEnrollmentDate);
            this.Controls.Add(this.lblEnrollmentDate);
            this.Controls.Add(this.txtEnrollmentCourseID);
            this.Controls.Add(this.lblEnrollmentCourseID);
            this.Controls.Add(this.txtEnrollmentStudentID);
            this.Controls.Add(this.btnCourse_Clear);
            this.Controls.Add(this.btnCourse_Save);
            this.Controls.Add(this.lblEnrollmentStudentID);
            this.Controls.Add(this.txtEnrollmentID);
            this.Controls.Add(this.txtCourseTitle);
            this.Controls.Add(this.lblEnrollmentID);
            this.Controls.Add(this.lblCourseTitle);
            this.Controls.Add(this.lblCourseID);
            this.Controls.Add(this.txtCourseID);
            this.Controls.Add(this.btnStudent_Clear);
            this.Controls.Add(this.btnStudent_Save);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.txtStudentLastName);
            this.Controls.Add(this.lblFirstName);
            this.Controls.Add(this.lblStudentID);
            this.Controls.Add(this.txtStudentID);
            this.Controls.Add(this.txtStudentFirstName);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbEnrollments);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbCourses);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbStudents);
            this.Name = "Registration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registration Data Inspector";
            this.Load += new System.EventHandler(this.Registration_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbStudents;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbCourses;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbEnrollments;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.TextBox txtStudentFirstName;
        private System.Windows.Forms.TextBox txtStudentID;
        private System.Windows.Forms.Label lblStudentID;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox txtStudentLastName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Button btnStudent_Save;
        private System.Windows.Forms.Button btnStudent_Clear;
        private System.Windows.Forms.TextBox txtCourseID;
        private System.Windows.Forms.Label lblCourseID;
        private System.Windows.Forms.Label lblCourseTitle;
        private System.Windows.Forms.Label lblEnrollmentID;
        private System.Windows.Forms.TextBox txtCourseTitle;
        private System.Windows.Forms.TextBox txtEnrollmentID;
        private System.Windows.Forms.Label lblEnrollmentStudentID;
        private System.Windows.Forms.Button btnCourse_Save;
        private System.Windows.Forms.Button btnCourse_Clear;
        private System.Windows.Forms.TextBox txtEnrollmentStudentID;
        private System.Windows.Forms.Label lblEnrollmentCourseID;
        private System.Windows.Forms.TextBox txtEnrollmentCourseID;
        private System.Windows.Forms.Label lblEnrollmentDate;
        private System.Windows.Forms.TextBox txtEnrollmentDate;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnStudent_Delete;
        private System.Windows.Forms.Button btnCourse_Delete;
        private System.Windows.Forms.Panel pnlStudent_Schedule;
        private System.Windows.Forms.ListView lvCourse_Roster;
        private System.Windows.Forms.Label lblCourseRoster;
    }
}