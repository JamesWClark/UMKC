﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ClarkHazlewood_CS303_Project_03 {
    public partial class RegistrationForm : Form {

        private Student student;
        private Course course;
        private Enrollment enrollment;

        private Dictionary<Guid, Student> Students = new Dictionary<Guid, Student>();
        private Dictionary<Guid, Course> Courses = new Dictionary<Guid, Course>();
        private Dictionary<Guid, Enrollment> Enrollments = new Dictionary<Guid, Enrollment>();

        public RegistrationForm() {
            InitializeComponent();
        }

        private void RegistrationForm_Load(object sender, EventArgs e) {
            LoadSamples();
        }

        private void LoadSamples() {
            //create some students and courses
            Course a = new Course("English 101");
            Course b = new Course("Math 300");
            Course c = new Course("Accounting 206");
            Student d = new Student("Jay", "Z");
            Student f = new Student("Bo", "Jackson");
            Student g = new Student("Snoop", "Lion");
            Courses.Add(a.CourseID, a);
            Courses.Add(b.CourseID, b);
            Courses.Add(c.CourseID, c);
            Students.Add(d.StudentID, d);
            Students.Add(f.StudentID, f);
            Students.Add(g.StudentID, g);
            cbStudents.DataSource = new BindingSource(Students, null);
            cbStudents.DisplayMember = "Value";
            cbStudents.ValueMember = "Key";
            cbCourses.DataSource = new BindingSource(Courses, null);
            cbCourses.DisplayMember = "Value";
            cbCourses.ValueMember = "Key";
            foreach (var course in Courses) {
                lvCoursesOffered.Items.Add(course.Value.ToString(), course.Key.ToString());
            }
            
        }

        private void lvCoursesOffered_SelectedIndexChanged(object sender, EventArgs e) {
            try {
                btnAddToSchedule.Enabled = true;
                Guid courseID = new Guid(lvCoursesOffered.SelectedItems[0].ImageKey);
            } catch (Exception) {

            }
        }

        private void cbStudents_SelectedIndexChanged(object sender, EventArgs e) {
            
        }

        private void btnAddToSchedule_Click(object sender, EventArgs e) {
            lblStub.Text = cbStudents.SelectedValue.ToString();
        }
    }
}
