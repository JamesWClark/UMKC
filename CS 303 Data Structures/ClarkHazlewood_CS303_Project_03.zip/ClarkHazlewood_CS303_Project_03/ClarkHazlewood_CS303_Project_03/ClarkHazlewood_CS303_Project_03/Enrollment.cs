﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClarkHazlewood_CS303_Project_03 {
    class Enrollment {
        public Guid EnrollmentID;
        public Guid StudentID;
        public Guid CourseID;
        public DateTime EnrollmentDate;

        public Enrollment(Guid student, Guid course) {
            this.StudentID = student;
            this.CourseID = course;
            this.EnrollmentID = Guid.NewGuid();
            this.EnrollmentDate = DateTime.Now;
        }

        public override string ToString() {
            return this.EnrollmentDate.ToString();
        }
    }
}
