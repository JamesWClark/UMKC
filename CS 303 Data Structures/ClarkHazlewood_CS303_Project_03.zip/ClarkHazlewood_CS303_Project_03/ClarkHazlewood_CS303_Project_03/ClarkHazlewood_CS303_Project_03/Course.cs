﻿using System;
using System.Collections.Generic;

namespace ClarkHazlewood_CS303_Project_03 {
    class Course {
        public Guid CourseID;
        public string Title;
        public HashSet<Enrollment> Enrollments = new HashSet<Enrollment>();

        public Course(string title) {
            this.CourseID = Guid.NewGuid();
            this.Title = title;
        }

        public override string ToString() {
            return this.Title;
        }
    }
}
