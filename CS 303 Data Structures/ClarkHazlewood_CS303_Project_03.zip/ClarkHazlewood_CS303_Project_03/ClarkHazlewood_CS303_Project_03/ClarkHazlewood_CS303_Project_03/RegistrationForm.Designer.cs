﻿namespace ClarkHazlewood_CS303_Project_03 {
    partial class RegistrationForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.cbStudents = new System.Windows.Forms.ComboBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabStudents = new System.Windows.Forms.TabPage();
            this.btnAddToSchedule = new System.Windows.Forms.Button();
            this.lblStudents = new System.Windows.Forms.Label();
            this.lvStudents = new System.Windows.Forms.ListView();
            this.tabCourses = new System.Windows.Forms.TabPage();
            this.lblCourses = new System.Windows.Forms.Label();
            this.lvCourses = new System.Windows.Forms.ListView();
            this.cbCourses = new System.Windows.Forms.ComboBox();
            this.lvCoursesOffered = new System.Windows.Forms.ListView();
            this.lblCoursesOffered = new System.Windows.Forms.Label();
            this.lblStub = new System.Windows.Forms.Label();
            this.tabAdmin = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.tabStudents.SuspendLayout();
            this.tabCourses.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbStudents
            // 
            this.cbStudents.FormattingEnabled = true;
            this.cbStudents.Location = new System.Drawing.Point(7, 7);
            this.cbStudents.Name = "cbStudents";
            this.cbStudents.Size = new System.Drawing.Size(200, 21);
            this.cbStudents.TabIndex = 0;
            this.cbStudents.SelectedIndexChanged += new System.EventHandler(this.cbStudents_SelectedIndexChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabAdmin);
            this.tabControl1.Controls.Add(this.tabStudents);
            this.tabControl1.Controls.Add(this.tabCourses);
            this.tabControl1.Location = new System.Drawing.Point(13, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(350, 437);
            this.tabControl1.TabIndex = 1;
            // 
            // tabStudents
            // 
            this.tabStudents.Controls.Add(this.btnAddToSchedule);
            this.tabStudents.Controls.Add(this.lblStudents);
            this.tabStudents.Controls.Add(this.lvStudents);
            this.tabStudents.Controls.Add(this.cbStudents);
            this.tabStudents.Location = new System.Drawing.Point(4, 22);
            this.tabStudents.Name = "tabStudents";
            this.tabStudents.Padding = new System.Windows.Forms.Padding(3);
            this.tabStudents.Size = new System.Drawing.Size(342, 411);
            this.tabStudents.TabIndex = 0;
            this.tabStudents.Text = "Students";
            this.tabStudents.UseVisualStyleBackColor = true;
            // 
            // btnAddToSchedule
            // 
            this.btnAddToSchedule.Enabled = false;
            this.btnAddToSchedule.Location = new System.Drawing.Point(214, 51);
            this.btnAddToSchedule.Name = "btnAddToSchedule";
            this.btnAddToSchedule.Size = new System.Drawing.Size(122, 23);
            this.btnAddToSchedule.TabIndex = 3;
            this.btnAddToSchedule.Text = "Add to Schedule";
            this.btnAddToSchedule.UseVisualStyleBackColor = true;
            this.btnAddToSchedule.Click += new System.EventHandler(this.btnAddToSchedule_Click);
            // 
            // lblStudents
            // 
            this.lblStudents.AutoSize = true;
            this.lblStudents.Location = new System.Drawing.Point(7, 35);
            this.lblStudents.Name = "lblStudents";
            this.lblStudents.Size = new System.Drawing.Size(62, 13);
            this.lblStudents.TabIndex = 2;
            this.lblStudents.Text = "Enrollment: ";
            // 
            // lvStudents
            // 
            this.lvStudents.Location = new System.Drawing.Point(7, 51);
            this.lvStudents.Name = "lvStudents";
            this.lvStudents.Size = new System.Drawing.Size(200, 354);
            this.lvStudents.TabIndex = 1;
            this.lvStudents.UseCompatibleStateImageBehavior = false;
            // 
            // tabCourses
            // 
            this.tabCourses.Controls.Add(this.lblCourses);
            this.tabCourses.Controls.Add(this.lvCourses);
            this.tabCourses.Controls.Add(this.cbCourses);
            this.tabCourses.Location = new System.Drawing.Point(4, 22);
            this.tabCourses.Name = "tabCourses";
            this.tabCourses.Padding = new System.Windows.Forms.Padding(3);
            this.tabCourses.Size = new System.Drawing.Size(342, 411);
            this.tabCourses.TabIndex = 1;
            this.tabCourses.Text = "Courses";
            this.tabCourses.UseVisualStyleBackColor = true;
            // 
            // lblCourses
            // 
            this.lblCourses.AutoSize = true;
            this.lblCourses.Location = new System.Drawing.Point(7, 35);
            this.lblCourses.Name = "lblCourses";
            this.lblCourses.Size = new System.Drawing.Size(62, 13);
            this.lblCourses.TabIndex = 2;
            this.lblCourses.Text = "Enrollment: ";
            // 
            // lvCourses
            // 
            this.lvCourses.HideSelection = false;
            this.lvCourses.Location = new System.Drawing.Point(7, 51);
            this.lvCourses.MultiSelect = false;
            this.lvCourses.Name = "lvCourses";
            this.lvCourses.Size = new System.Drawing.Size(200, 354);
            this.lvCourses.TabIndex = 1;
            this.lvCourses.UseCompatibleStateImageBehavior = false;
            this.lvCourses.View = System.Windows.Forms.View.List;
            // 
            // cbCourses
            // 
            this.cbCourses.FormattingEnabled = true;
            this.cbCourses.Location = new System.Drawing.Point(7, 7);
            this.cbCourses.Name = "cbCourses";
            this.cbCourses.Size = new System.Drawing.Size(200, 21);
            this.cbCourses.TabIndex = 0;
            // 
            // lvCoursesOffered
            // 
            this.lvCoursesOffered.HideSelection = false;
            this.lvCoursesOffered.Location = new System.Drawing.Point(369, 35);
            this.lvCoursesOffered.MultiSelect = false;
            this.lvCoursesOffered.Name = "lvCoursesOffered";
            this.lvCoursesOffered.Size = new System.Drawing.Size(200, 415);
            this.lvCoursesOffered.TabIndex = 2;
            this.lvCoursesOffered.UseCompatibleStateImageBehavior = false;
            this.lvCoursesOffered.View = System.Windows.Forms.View.List;
            this.lvCoursesOffered.SelectedIndexChanged += new System.EventHandler(this.lvCoursesOffered_SelectedIndexChanged);
            // 
            // lblCoursesOffered
            // 
            this.lblCoursesOffered.AutoSize = true;
            this.lblCoursesOffered.Location = new System.Drawing.Point(369, 19);
            this.lblCoursesOffered.Name = "lblCoursesOffered";
            this.lblCoursesOffered.Size = new System.Drawing.Size(151, 13);
            this.lblCoursesOffered.TabIndex = 3;
            this.lblCoursesOffered.Text = "Courses offered this semester: ";
            // 
            // lblStub
            // 
            this.lblStub.AutoSize = true;
            this.lblStub.Location = new System.Drawing.Point(127, 9);
            this.lblStub.Name = "lblStub";
            this.lblStub.Size = new System.Drawing.Size(0, 13);
            this.lblStub.TabIndex = 4;
            // 
            // tabAdmin
            // 
            this.tabAdmin.Location = new System.Drawing.Point(4, 22);
            this.tabAdmin.Name = "tabAdmin";
            this.tabAdmin.Size = new System.Drawing.Size(342, 411);
            this.tabAdmin.TabIndex = 2;
            this.tabAdmin.Text = "Admin";
            this.tabAdmin.UseVisualStyleBackColor = true;
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(581, 462);
            this.Controls.Add(this.lblStub);
            this.Controls.Add(this.lblCoursesOffered);
            this.Controls.Add(this.lvCoursesOffered);
            this.Controls.Add(this.tabControl1);
            this.Name = "RegistrationForm";
            this.Text = "Course Registration";
            this.Load += new System.EventHandler(this.RegistrationForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabStudents.ResumeLayout(false);
            this.tabStudents.PerformLayout();
            this.tabCourses.ResumeLayout(false);
            this.tabCourses.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbStudents;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabStudents;
        private System.Windows.Forms.TabPage tabCourses;
        private System.Windows.Forms.ComboBox cbCourses;
        private System.Windows.Forms.ListView lvCoursesOffered;
        private System.Windows.Forms.Label lblCoursesOffered;
        private System.Windows.Forms.Label lblStudents;
        private System.Windows.Forms.ListView lvStudents;
        private System.Windows.Forms.Label lblCourses;
        private System.Windows.Forms.ListView lvCourses;
        private System.Windows.Forms.Button btnAddToSchedule;
        private System.Windows.Forms.Label lblStub;
        private System.Windows.Forms.TabPage tabAdmin;



    }
}

