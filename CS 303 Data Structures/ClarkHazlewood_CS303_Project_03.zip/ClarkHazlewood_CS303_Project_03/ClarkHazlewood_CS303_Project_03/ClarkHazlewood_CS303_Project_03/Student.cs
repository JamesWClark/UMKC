﻿using System;
using System.Collections.Generic;

namespace ClarkHazlewood_CS303_Project_03 {
    class Student {
        public Guid StudentID;
        public string FirstName;
        public string LastName;
        public HashSet<Enrollment> Enrollments = new HashSet<Enrollment>();

        public Student(string firstName, string lastName) {
            this.StudentID = Guid.NewGuid();
            this.FirstName = firstName;
            this.LastName = lastName;
        }

        public override string ToString() {
            return this.LastName + ", " + this.FirstName;
        }
    }
}
