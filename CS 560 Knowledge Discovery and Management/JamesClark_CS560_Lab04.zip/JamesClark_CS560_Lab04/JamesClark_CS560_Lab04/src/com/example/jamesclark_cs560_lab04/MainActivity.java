package com.example.jamesclark_cs560_lab04;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	private Button btnSearch;
	private TextView lblStub;
	
	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		
		super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.setThreadPolicy(policy);

        btnSearch = (Button)findViewById(R.id.btnSearch);
        lblStub = (TextView)findViewById(R.id.lblStub);
        
        btnSearch.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				HttpClient client = new DefaultHttpClient();
				HttpResponse response;
				String rString = null;

				String solr = getResources().getString(R.string.solr);

				//HTTP request
				try {
					HttpGet get = new HttpGet(solr);
					response = client.execute(get);
					StatusLine status = response.getStatusLine();

					if(status.getStatusCode() == HttpStatus.SC_OK) {
						ByteArrayOutputStream output = new ByteArrayOutputStream();
						response.getEntity().writeTo(output);
						output.close();
						rString = output.toString();			
						
				    	//print service response
				    	lblStub.setText(rString);
					}

				} catch (ClientProtocolException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
