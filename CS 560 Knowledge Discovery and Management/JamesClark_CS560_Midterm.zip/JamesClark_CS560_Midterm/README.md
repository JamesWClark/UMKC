JamesClark_CS560_Midterm
========================
