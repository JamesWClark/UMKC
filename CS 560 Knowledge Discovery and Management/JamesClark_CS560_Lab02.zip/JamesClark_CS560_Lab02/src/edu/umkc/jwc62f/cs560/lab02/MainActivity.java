package edu.umkc.jwc62f.cs560.lab02;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DecimalFormat;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	private EditText txtCity;
	private Button btnSearch;
	private TextView lblStub;
	
	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.setThreadPolicy(policy);
        
        txtCity = (EditText)findViewById(R.id.text_city);
        btnSearch = (Button)findViewById(R.id.btnSearch);
        lblStub = (TextView)findViewById(R.id.lblStub);
        
        btnSearch.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				HttpClient client = new DefaultHttpClient();
				HttpResponse response;
				String rString = null;
				
				String city = txtCity.getText().toString();
				
				
				String url = getResources().getString(R.string.svc_weather) + "?q=" + EncodeUrl(city);
					
				//HTTP request
				try {
					HttpPost post = new HttpPost(url);
					response = client.execute(post);
					StatusLine status = response.getStatusLine();
					
					if(status.getStatusCode() == HttpStatus.SC_OK) {
						ByteArrayOutputStream output = new ByteArrayOutputStream();
						response.getEntity().writeTo(output);
						output.close();
						rString = output.toString();						
				    	
						//parse JSON object
						int code;
						String description = "";
				    	String temp = "";
				    	String low = "";
				    	String high = "";
				    	String error = "";
				    	StringBuilder sb = new StringBuilder();
				    	try {
					    	JSONObject jsonObject = new JSONObject(rString);
					    	
					    	code = jsonObject.getInt("cod");
					    	
					    	switch(code) {
						    	case 200:
							    	JSONObject weatherObject = jsonObject.getJSONArray("weather").getJSONObject(0);
							    	JSONObject mainObject = jsonObject.getJSONObject("main");
							    	description = weatherObject.getString("description");
							    	temp = mainObject.getString("temp");
							    	low = mainObject.getString("temp_min");
							    	high = mainObject.getString("temp_max");
							    	sb.append("Current Temp: " + KtoF(temp));
							    	sb.append("\nLow: " + KtoF(low));
							    	sb.append("\nHigh: " + KtoF(high));
							    	sb.append("\nDescription: " + description);
						    		break;
						    	case 404:
						    		error = jsonObject.getString("message");
						    		sb.append(error);
						    		break;
					    	}					    	
					    } catch (JSONException e) {
					    	e.printStackTrace();
					    }
				    	//print service response
				    	lblStub.setText(sb.toString());
					}
						
				} catch (ClientProtocolException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
    }
    //encode a URL, replace spaces and such
    public String EncodeUrl(String url){
    	try{
    		url = URLEncoder.encode(url, "utf-8");
    	} catch (UnsupportedEncodingException e) {
    		e.printStackTrace();
    	}
    	return url;
    }
    //convert Kelvin to Fahrenheit
    public String KtoF(String K){
    	DecimalFormat d = new DecimalFormat("#");
    	return d.format((Double.parseDouble(K) - 273.15) * 1.8 + 32);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
